# Robot de réconfort — Fauron & Lamkaddem & Thomas

Projet de semestre, master informatique. Un robot à perception locale
consulte un dictionnaire, fouille une armoire et rapporte un objet à un
résident.

Langage : Python — Version : 3

## Lancer

Exemple:
```
python3 -m main cartes/appartement_01.json scenarios/scenario_01.json donnees sorties/trace_GroupeFLT.json 
```
# Puis
```
 ./affichage.py sorties/trace_GroupeFLT.json
```

Si besoin: 
```
chmod +x affichage.py
```

Dépendances :
̀```
sudo apt install python3-tk
```

## Tester

```
python3 -m unittest discover -s test -v
```

*Une phrase sur ce que couvrent les tests.*

## Organisation du code

| Fichier | Rôle |
|---|---|
| `main.py` | point d'entrée, initialise environment et lance la boucle principale env.run |
|`src.Environment.py`|chef d'orchestre: stocke les datas, initialise l'agent Robot, définis les rêgle physique du monde,à chaque pas : fournie à l'agent sa perception - récupère les actions des agents - éxecute les actions|
|
| `…` | … |

## État

**Ce qui marche.** *À compléter.*

**Ce qui ne marche pas.** *À compléter — soyez honnêtes, c'est noté en
votre faveur.*

## Vidéo

`demo.mp4` (ou le lien), également déclarée dans `rendu.json`.
